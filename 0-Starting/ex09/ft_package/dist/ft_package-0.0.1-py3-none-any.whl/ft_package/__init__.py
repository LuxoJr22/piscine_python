def count_in_list(array, elem):
	count = 0
	for i in array:
		if (i == elem):
			count += 1
	return (count)